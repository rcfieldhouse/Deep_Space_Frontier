#pragma once
#ifndef _GAME_OBJECT_
#define _GAME_OBJECT

#include "TestPlugin.h"
#include "ProjectSettings.h"

#include <fstream>
#include <iostream>
#include <string>
#include <vector>
using namespace std;

class PLUGIN_API GameObject
{
public:
	GameObject();

	int GetID() const;
	void SetID(int id = 0);

	Vector3 GetPosition();
	void SetPosition(float x = 0.0f, float y = 0.0f, float z = 0.0f);

	ofstream WriteFile;
	ifstream ReadFile;

	//Saving
	void SaveToFile(int id, float x, float y, float z, float Health);
	void StartWriting(const char* f);
	void EndWriting();
	//Reading
	void ReadPlayerPosFile();
	void StartReading(const char* fN);
	void EndReading();
	//Loading
	float LoadFromFile(int j, const char* fileName);
	int GetLines(const char* fileName);

	vector <float> line;

private:
	int m_id;
	Vector3 m_position;
	Vector3 PlayerFilePos;
	string s_PlayerFilePos;
};

#endif

