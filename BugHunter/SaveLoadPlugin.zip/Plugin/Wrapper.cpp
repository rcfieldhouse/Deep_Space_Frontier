#include "Wrapper.h"
#include "GameObject.h"

GameObject gameObject;

PLUGIN_API int GetID()
{
	return gameObject.GetID();
}

PLUGIN_API void SetID(const int id)
{
	gameObject.SetID();
}

PLUGIN_API Vector3 GetPosition()
{
	return gameObject.GetPosition();
}

PLUGIN_API void SetPosition(float x, float y, float z)
{
	gameObject.SetPosition(x, y, z);
}

// file saving
PLUGIN_API void SaveToFile(int id, float x, float y, float z, float Health)
{
	gameObject.SaveToFile(id, x, y, z, Health);
}

PLUGIN_API void StartWriting(const char* fileName)
{
	gameObject.StartWriting(fileName);
}

PLUGIN_API void EndWriting()
{
	gameObject.EndWriting();
}

//File Loading
PLUGIN_API float LoadFromFile(int j, const char* fileName)
{
	return gameObject.LoadFromFile(j, fileName);
}

PLUGIN_API int GetLines(const char* fileName)
{
	return gameObject.GetLines(fileName);
}

// File Reading
PLUGIN_API void ReadPlayerPosFile()
{
	gameObject.ReadPlayerPosFile();
}

PLUGIN_API void StartReading(const char* fileName)
{
	gameObject.StartReading(fileName);
}

PLUGIN_API void EndReading()
{
	gameObject.EndReading();
}