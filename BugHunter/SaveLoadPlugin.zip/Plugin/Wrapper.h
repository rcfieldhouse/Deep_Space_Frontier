#pragma once
#ifndef _WRAPPER_
#define _WRAPPER_

#endif

#include "ProjectSettings.h"
#include "TestPlugin.h"

#ifdef __cplusplus
extern "C"
{
#endif
	PLUGIN_API int GetID();
	PLUGIN_API void SetID(int id);

	PLUGIN_API Vector3 GetPosition();
	PLUGIN_API void SetPosition(float x, float y, float z);

	PLUGIN_API void SaveToFile(int id, float x, float y, float z, float Health);
	PLUGIN_API void StartWriting(const char* f);
	PLUGIN_API void EndWriting();

	PLUGIN_API float LoadFromFile(int j, const char* fileName);
	PLUGIN_API int GetLines(const char* fileName);

	PLUGIN_API void ReadPlayerPosFile();
	PLUGIN_API void StartReading(const char* f);
	PLUGIN_API void EndReading();
#ifdef __cplusplus
}
#endif


/*class Wrapper
{

};*/

