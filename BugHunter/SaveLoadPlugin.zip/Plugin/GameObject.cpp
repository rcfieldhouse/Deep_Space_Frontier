#include "GameObject.h"

GameObject::GameObject()
{
	SetID();
	SetPosition();
}

int GameObject::GetID() const
{
	return m_id;

}

void GameObject::SetID(const int id)
{
	m_id = id;
}

Vector3 GameObject::GetPosition()
{
	return m_position;
}

void GameObject::SetPosition(float x, float y, float z)
{
	m_position.x = x;
	m_position.y = y;
	m_position.z = z;
}


void GameObject::SaveToFile(int objectID, float x, float y, float z, float Health)
{
	//WriteFile << objectID << "\n";
	WriteFile << x << "\n";
	WriteFile << y << "\n";
	WriteFile << z << "\n";
	WriteFile << Health << "\n";
}

void GameObject::StartWriting(const char* fileName)
{
	WriteFile.open(fileName);
}

void GameObject::EndWriting()
{
	WriteFile.close();
}

float GameObject::LoadFromFile(int j, const char* fileName)
{
	line.clear();
	ifstream myFile;
	myFile.open(fileName);
	float value;

	while (myFile >> value)
	{
		// will add value as last element in vector
		line.push_back(value);
	}
	myFile.close();
	return line[j];
}

// returns # of lines in text file
int GameObject::GetLines(const char* fileName)
{
	line.clear();
	ifstream myFile;
	myFile.open(fileName);
	int numl = 0;

	string tempString;
	// goes through each of the lines then splits the content in the text file based on the character we request
	// default is "\n"
	while (getline(myFile, tempString))
	{
		numl++;
	}
	myFile.close();
	return numl;
}

// Not Used
void GameObject::ReadPlayerPosFile()
{
	int lineNum = 0;

	if (ReadFile.is_open() == true)
	{
		while (lineNum != 3 && getline(ReadFile, s_PlayerFilePos))
		{
			if (lineNum == 0)
			{
				PlayerFilePos.x = stof(s_PlayerFilePos);
			}
			if (lineNum == 1)
			{
				PlayerFilePos.y = stof(s_PlayerFilePos);
			}
			if (lineNum == 2)
			{
				PlayerFilePos.z = stof(s_PlayerFilePos);
			}
			lineNum++;
		}
	}
	//return PlayerFilePos;
	
}

void GameObject::StartReading(const char* fileName)
{
	ReadFile.open(fileName);
}

void GameObject::EndReading()
{
	ReadFile.close();
}