// Plugin.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "GameObject.h"

using namespace std;

int main()
{
    GameObject gameObject;

    gameObject.SetID(1);
    gameObject.SetPosition(100.0f, 200.0f, 300.0f);

    std::cout << gameObject.GetID() << std::endl;
    std::cout << "(" << gameObject.GetPosition().x << "," << gameObject.GetPosition().y << "," << gameObject.GetPosition().z << ")" << std::endl;
}
