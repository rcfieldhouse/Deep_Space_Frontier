#pragma once
#ifndef _VECTOR3_
#define _VECTOR3_

struct Vector3
{
	float x;
	float y;
	float z;

};

#endif