#include "Wrapper.h"
#include "UserTime.h"

UserTime uTimeObj;

PLUGIN_API int GenerateHour()
{
	return uTimeObj.GenerateHour();
}

PLUGIN_API int GenerateMin()
{
	return uTimeObj.GenerateMin();
}

PLUGIN_API int GenerateSec()
{
	return uTimeObj.GenerateSec();
}