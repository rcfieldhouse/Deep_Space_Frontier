#include "UserTime.h"

UserTime::UserTime()
{

}


int UserTime::GenerateHour()
{
    __time64_t long_time;
    struct tm localTime;

    _time64(&long_time);
    localtime_s(&localTime, &long_time);

    int Hour = localTime.tm_hour;

    return Hour;
}

int UserTime::GenerateMin()
{
    __time64_t long_time;
    struct tm localTime;

    _time64(&long_time);
    localtime_s(&localTime, &long_time);

    int Min = localTime.tm_min;


    return Min;
}
int UserTime::GenerateSec()
{
    __time64_t long_time;
    struct tm localTime;

    _time64(&long_time);
    localtime_s(&localTime, &long_time);

    int Sec = localTime.tm_sec;

    return Sec;
}
