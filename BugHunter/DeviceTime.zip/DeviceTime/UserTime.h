#pragma once
#ifndef _USER_TIME
#define _USER_TIME

#include <ctime>
//#include <chrono>
//#include <string>
//#include <vector>

#include "ProjectSettings.h"

class PLUGIN_API UserTime
{
public:
	UserTime();

	int GenerateHour();
	int GenerateMin();
	int GenerateSec();
};
#endif

