#pragma once
#ifndef _WRAPPER_
#define _WRAPPER_

#include "ProjectSettings.h"
#include <string>

#ifdef __cplusplus
extern "C"
{
#endif
	PLUGIN_API int GenerateHour();
	PLUGIN_API int GenerateMin();
	PLUGIN_API int GenerateSec();

#ifdef __cplusplus
};
#endif

#endif

